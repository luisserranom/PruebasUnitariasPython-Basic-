import unittest
from webbrowser import Opera
import Operaciones

class test_Operaciones(unittest.TestCase):

    def test_suma_valido(self):
        #arrange
        v1 = 10
        v2 = 10
        res_esperado = 20
        res_actual = 0

        #act
        operaciones = Operaciones.Operaciones()
        res_actual = operaciones.suma(v1,v2)

        #assert
        self.assertEqual(res_actual, res_esperado)
        

    def test_resta_valido(self):
        v1 = 2
        v2 = 1
        res_esperado = 1
        res_actual = 0

        operaciones = Operaciones.Operaciones()
        res_actual = operaciones.resta(v1,v2)

        self.assertEqual(res_actual,res_esperado)
        
    def test_multiplicacion_valido(self):
        v1 = 2
        v2 = 2
        res_esperado = 4
        res_actual = 0

        operaciones = Operaciones.Operaciones()
        res_actual = operaciones.multiplicacion(v1,v2)

        self.assertEqual(res_actual,res_esperado)

    def test_division_valido(self):
        v1 = 4
        v2 = 2
        res_esperado = 2
        res_actual = 0

        operaciones = Operaciones.Operaciones()
        res_actual = operaciones.division(v1,v2)

        self.assertEqual(res_actual,res_esperado)

    
    def test_potencia_valido(self):
        v1 = 5
        v2 = 2
        res_esperado = 25
        res_actual = 0

        operaciones = Operaciones.Operaciones()
        res_actual = operaciones.multiplicacion(v1,v2)

        self.assertEqual(res_actual,res_esperado)