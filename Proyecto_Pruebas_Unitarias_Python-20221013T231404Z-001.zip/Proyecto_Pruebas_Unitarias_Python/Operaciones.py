class Operaciones:

    def suma(self,a,b):
        return a+b

    def resta(self,a,b):
        return a-b

    def multiplicacion(self,a,b):
        return a*b

    def division(self,a,b):
        return a/b

    def potencia(self,a,b):
        return a**b

    